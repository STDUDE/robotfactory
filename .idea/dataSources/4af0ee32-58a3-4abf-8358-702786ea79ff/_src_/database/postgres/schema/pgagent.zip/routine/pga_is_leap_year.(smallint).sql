create function pga_is_leap_year(smallint) returns boolean
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN
    IF $1 % 4 != 0 THEN
        RETURN FALSE;
    END IF;

    IF $1 % 100 != 0 THEN
        RETURN TRUE;
    END IF;

    RETURN $1 % 400 = 0;
END;
$$;
